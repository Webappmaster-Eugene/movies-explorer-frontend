import InfoToolTip from './InfoToolTip';

export default InfoToolTip;
