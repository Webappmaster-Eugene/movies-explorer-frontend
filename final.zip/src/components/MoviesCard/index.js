import MoviesCard from './MoviesCard';
export default MoviesCard;
