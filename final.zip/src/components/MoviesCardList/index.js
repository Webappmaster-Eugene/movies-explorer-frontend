import MoviesCardList from './MoviesCardList';
export default MoviesCardList;
