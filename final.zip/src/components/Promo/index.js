import Promo from './Promo';
export default Promo;
