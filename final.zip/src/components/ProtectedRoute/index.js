import ProtectedRoute from './ProtectedRoute';
export default ProtectedRoute;
