import SavedMovies from './SavedMovies';
export default SavedMovies;
