import Techs from './Techs';
export default Techs;
